package com.example.admin.adminUIDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminUiDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminUiDemoApplication.class, args);
	}
}
